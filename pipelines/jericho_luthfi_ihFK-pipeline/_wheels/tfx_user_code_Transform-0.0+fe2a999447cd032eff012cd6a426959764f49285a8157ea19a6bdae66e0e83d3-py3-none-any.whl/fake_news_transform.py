
import tensorflow as tf

LABEL_KEY = "Label"
FEATURE_KEY = "Body"


def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"


def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features

    Args:
        inputs: map from feature keys to raw features.

    Return:
        outputs: map from feature keys to transformed features.
    """

    outputs = {}

    # Convert SparseTensor to Tensor
    feature_tensor = tf.sparse.to_dense(inputs[FEATURE_KEY], default_value='')

    # Apply lower case transformation and ensure fixed length
    feature_tensor_lower = tf.strings.lower(feature_tensor)
    feature_tensor_fixed_len = tf.strings.substr(feature_tensor_lower, 0, 256)  # Adjust length as needed

    outputs[transformed_name(FEATURE_KEY)] = feature_tensor_fixed_len

    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)

    return outputs
