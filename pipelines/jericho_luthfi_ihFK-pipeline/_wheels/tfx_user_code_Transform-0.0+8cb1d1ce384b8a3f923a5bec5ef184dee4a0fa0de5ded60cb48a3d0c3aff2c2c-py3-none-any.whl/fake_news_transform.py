
import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "Label"
FEATURE_KEY = "Headline"


def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"


def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features

    Args:
        inputs: map from feature keys to raw features.

    Return:
        outputs: map from feature keys to transformed features.
    """

    outputs = {}

    # Check if FEATURE_KEY is a SparseTensor
    if isinstance(inputs[FEATURE_KEY], tf.sparse.SparseTensor):
        # Convert SparseTensor to Tensor
        feature_tensor = tf.sparse.to_dense(inputs[FEATURE_KEY], default_value='')
    else:
        feature_tensor = inputs[FEATURE_KEY]

    # Apply lower case transformation
    feature_tensor_lower = tf.strings.lower(feature_tensor)

    # Truncate or pad the sequences to ensure fixed length
    max_length = 256  # Adjust as needed
    feature_tensor_fixed_len = tf.strings.substr(feature_tensor_lower, 0, max_length)

    # Ensure the shape is fixed
    feature_tensor_fixed_len = tf.reshape(feature_tensor_fixed_len, [-1, max_length])

    outputs[transformed_name(FEATURE_KEY)] = feature_tensor_fixed_len

    # Check if LABEL_KEY is a SparseTensor
    if isinstance(inputs[LABEL_KEY], tf.sparse.SparseTensor):
        # Convert SparseTensor to dense
        label_tensor = tf.sparse.to_dense(inputs[LABEL_KEY], default_value=0)
    else:
        label_tensor = inputs[LABEL_KEY]

    outputs[transformed_name(LABEL_KEY)] = tf.cast(label_tensor, tf.int64)

    return outputs

transform = Transform(
    examples=example_gen.outputs['examples'],
    schema=schema_gen.outputs['schema'],
    module_file=os.path.abspath(TRANSFORM_MODULE_FILE)
)
interactive_context.run(transform)
