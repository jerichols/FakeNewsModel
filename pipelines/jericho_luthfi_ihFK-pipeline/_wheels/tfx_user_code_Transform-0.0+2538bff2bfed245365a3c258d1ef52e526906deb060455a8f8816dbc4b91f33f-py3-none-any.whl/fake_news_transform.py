
import tensorflow as tf

LABEL_KEY = "Label"
FEATURE_KEY = "Body"


def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"


def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features

    Args:
        inputs: map from feature keys to raw features.

    Return:
        outputs: map from feature keys to transformed features.
    """

    outputs = {}

    # Convert SparseTensor to Tensor
    feature_tensor = tf.sparse.to_dense(inputs[FEATURE_KEY], default_value='')

    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(feature_tensor)

    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)

    return outputs
