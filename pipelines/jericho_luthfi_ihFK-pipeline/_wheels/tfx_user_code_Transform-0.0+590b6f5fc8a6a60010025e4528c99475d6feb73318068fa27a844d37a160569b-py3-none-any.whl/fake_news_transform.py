
import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "Label"
FEATURE_KEY = "Body"


def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"


def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features

    Args:
        inputs: map from feature keys to raw features.

    Return:
        outputs: map from feature keys to transformed features.
    """

    outputs = {}

    # Convert SparseTensor to Tensor
    feature_tensor = tf.sparse.to_dense(inputs[FEATURE_KEY], default_value='')
    
    # Apply lower case transformation
    feature_tensor_lower = tf.strings.lower(feature_tensor)

    # Truncate or pad the sequences to ensure fixed length
    max_length = 256  # Adjust as needed
    feature_tensor_fixed_len = tf.strings.substr(feature_tensor_lower, 0, max_length)

    # Ensure the shape is fixed
    feature_tensor_fixed_len = tf.reshape(feature_tensor_fixed_len, [-1, max_length])

    outputs[transformed_name(FEATURE_KEY)] = feature_tensor_fixed_len

    # For the label, convert SparseTensor to dense
    label_tensor = tf.sparse.to_dense(inputs[LABEL_KEY], default_value=0)
    outputs[transformed_name(LABEL_KEY)] = tf.cast(label_tensor, tf.int64)

    return outputs
